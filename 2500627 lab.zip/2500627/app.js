/*
  Name: Roheela
  Registration Number: 2500627
  Lab Assignment 5: Interactive To-Do List
*/

// State management
let tasks = [];
let currentFilter = 'all';

// DOM Elements
const todoForm = document.getElementById('todo-form');
const taskInput = document.getElementById('task-input');
const errorMessage = document.getElementById('error-message');
const taskList = document.getElementById('task-list');
const totalCount = document.getElementById('total-count');
const remainingCount = document.getElementById('remaining-count');
const filterButtons = document.querySelectorAll('.filter-btn');
const clearCompletedBtn = document.getElementById('clear-completed');

// Form Submission & Validation
todoForm.addEventListener('submit', (e) => {
  e.preventDefault();
  const text = taskInput.value.trim();

  // Check for empty input
  if (!text) {
    showError('Task description cannot be empty.');
    return;
  }

  // Check for duplicate tasks (case-insensitive)
  const isDuplicate = tasks.some(
    (task) => task.text.toLowerCase() === text.toLowerCase()
  );

  if (isDuplicate) {
    showError('This task already exists.');
    return;
  }

  clearError();
  addTask(text);
  taskInput.value = '';
});

function showError(msg) {
  errorMessage.textContent = msg;
}

function clearError() {
  errorMessage.textContent = '';
}

function addTask(text) {
  const newTask = {
    id: Date.now().toString(),
    text: text,
    completed: false,
    isEditing: false
  };
  tasks.push(newTask);
  render();
}

// Event Delegation on Task List Container
taskList.addEventListener('click', (e) => {
  const target = e.target;
  const li = target.closest('li');
  if (!li) return;
  const taskId = li.dataset.id;

  // Handle Checkbox Click
  if (target.classList.contains('complete-checkbox')) {
    toggleComplete(taskId);
  }

  // Handle Delete Button Click
  if (target.classList.contains('delete-btn')) {
    deleteTask(taskId);
  }
});

// Double-click to Edit Task (Bonus)
taskList.addEventListener('dblclick', (e) => {
  if (e.target.classList.contains('task-text')) {
    const li = e.target.closest('li');
    const taskId = li.dataset.id;
    startEditing(taskId);
  }
});

// Handle Editing Keyboard Shortcuts (Enter & Escape)
taskList.addEventListener('keydown', (e) => {
  if (!e.target.classList.contains('edit-input')) return;
  const li = e.target.closest('li');
  const taskId = li.dataset.id;

  if (e.key === 'Enter') {
    saveEditing(taskId, e.target.value.trim());
  } else if (e.key === 'Escape') {
    cancelEditing(taskId);
  }
});

taskList.addEventListener('focusout', (e) => {
  if (e.target.classList.contains('edit-input')) {
    const li = e.target.closest('li');
    const taskId = li.dataset.id;
    saveEditing(taskId, e.target.value.trim());
  }
});

function toggleComplete(id) {
  tasks = tasks.map((task) =>
    task.id === id ? { ...task, completed: !task.completed } : task
  );
  render();
}

function deleteTask(id) {
  tasks = tasks.filter((task) => task.id !== id);
  render();
}

function startEditing(id) {
  tasks = tasks.map((task) =>
    task.id === id ? { ...task, isEditing: true } : task
  );
  render();
}

function saveEditing(id, newText) {
  if (!newText) {
    showError('Task text cannot be empty during edit.');
    return;
  }
  
  const isDuplicate = tasks.some(
    (task) => task.id !== id && task.text.toLowerCase() === newText.toLowerCase()
  );

  if (isDuplicate) {
    showError('Another task with this text already exists.');
    return;
  }

  clearError();
  tasks = tasks.map((task) =>
    task.id === id ? { ...task, text: newText, isEditing: false } : task
  );
  render();
}

function cancelEditing(id) {
  clearError();
  tasks = tasks.map((task) =>
    task.id === id ? { ...task, isEditing: false } : task
  );
  render();
}

// Filter Buttons Handling
filterButtons.forEach((btn) => {
  btn.addEventListener('click', () => {
    filterButtons.forEach((b) => b.classList.remove('active'));
    btn.classList.add('active');
    currentFilter = btn.dataset.filter;
    render();
  });
});

// Clear Completed Tasks
clearCompletedBtn.addEventListener('click', () => {
  tasks = tasks.filter((task) => !task.completed);
  render();
});

// Render Function (UI Updates & Counter Updates)
function render() {
  // Filter tasks
  const filteredTasks = tasks.filter((task) => {
    if (currentFilter === 'active') return !task.completed;
    if (currentFilter === 'completed') return task.completed;
    return true;
  });

  // Clear list
  taskList.innerHTML = '';

  if (filteredTasks.length === 0) {
    taskList.innerHTML = `<li class="empty-state">No tasks to display</li>`;
  } else {
    filteredTasks.forEach((task) => {
      const li = document.createElement('li');
      li.className = `task-item ${task.completed ? 'completed' : ''}`;
      li.dataset.id = task.id;

      if (task.isEditing) {
        li.innerHTML = `
          <input type="text" class="edit-input" value="${task.text}" />
        `;
        setTimeout(() => {
          const input = li.querySelector('.edit-input');
          if (input) {
            input.focus();
            input.setSelectionRange(input.value.length, input.value.length);
          }
        }, 0);
      } else {
        li.innerHTML = `
          <div class="task-left">
            <input type="checkbox" class="complete-checkbox" ${
              task.completed ? 'checked' : ''
            }>
            <span class="task-text">${escapeHtml(task.text)}</span>
          </div>
          <button class="delete-btn">Delete</button>
        `;
      }

      taskList.appendChild(li);
    });
  }

  // Update Live Counters
  const total = tasks.length;
  const remaining = tasks.filter((task) => !task.completed).length;

  totalCount.textContent = total;
  remainingCount.textContent = remaining;
}

// Utility function to prevent XSS
function escapeHtml(text) {
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}

// Initial Render
render();